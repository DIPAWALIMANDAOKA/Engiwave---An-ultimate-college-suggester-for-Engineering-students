from flask import Flask, render_template, request, redirect, url_for, session, flash
from functools import wraps
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, ValidationError
import bcrypt
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.cluster import KMeans

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

class RegisterForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Register")

class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('You need to login first.')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route("/")
def home():
    return render_template("homepage.html")

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        name = form.name.data
        email = form.email.data
        password = form.password.data
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        # For demonstration purposes, store user data in session
        session['user'] = {'name': name, 'email': email, 'password': hashed_password}

        flash("Registration successful. Please login.")
        return redirect(url_for('homepage'))

    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data

        # For demonstration purposes, check login credentials from session
        user = session.get('user')
        if user and bcrypt.checkpw(password.encode('utf-8'), user['password']):
            session['user_id'] = email  # For simplicity, use email as user_id
            flash("Login successful.")
            return redirect(url_for('home'))
        else:
            flash("Login failed. Please check your email and password")

    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash("You have been logged out successfully.")
    return redirect(url_for('login'))

@app.route("/LoginSignup")
def LoginSignup():
    return render_template("LoginSignup.html")

@app.route("/explore_branches")
@login_required
def explore_branches():
    return render_template("explore_branches.html")

@app.route("/about")
@login_required
def about():
    return render_template("about.html")

@app.route("/feedback")
@login_required
def feedback():
    return render_template("feedback.html")

# Load your dataset
df = pd.read_csv('EngiWave123\EngiWave123\cleaned_data.csv')  # Change 'your_dataset.csv' to your actual dataset file

# Perform label encoding
le_category = LabelEncoder()
le_quota = LabelEncoder()
le_branch = LabelEncoder()
le_location = LabelEncoder()
le_college = LabelEncoder()

df['category'] = le_category.fit_transform(df['category'])
df['quota'] = le_quota.fit_transform(df['quota'])
df['Branch'] = le_branch.fit_transform(df['Branch'])
df['location'] = le_location.fit_transform(df['location'])
df['College Name'] = le_college.fit_transform(df['College Name'])

# Train Decision Tree Classifier
X = df[['round_no', 'Branch', 'quota', 'category', 'Closing_CutOff', 'location']]
y = df['College Name']

decision_tree_classifier = DecisionTreeClassifier(random_state=42)
decision_tree_classifier.fit(X, y)

# Train KMeans clustering
num_clusters = 10  # Adjust the number of clusters as needed
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
df['Cluster'] = kmeans.fit_predict(X)

@app.route('/form', methods=['GET', 'POST'])

def form():
    if request.method == 'POST':
        round_no = int(request.form['round_no'])
        branch = request.form['branch']
        quota = request.form['quota']
        category = request.form['category']
        closing_cut_off = int(request.form['closing_cut_off'])
        location = request.form['location']

        input_data = [[round_no, le_branch.transform([branch])[0], le_quota.transform([quota])[0],
                       le_category.transform([category])[0], closing_cut_off, le_location.transform([location])[0]]]

        prediction = decision_tree_classifier.predict(input_data)
        cluster_prediction = kmeans.predict(input_data)[0]

        # Filter colleges based on the cluster and get unique colleges
        unique_colleges = df[df['Cluster'] == cluster_prediction].groupby('College Name').first().reset_index()

        # Convert unique_colleges back to categorical form
        recommended_colleges = le_college.inverse_transform(unique_colleges['College Name'])[:10]

        return render_template('result.html', predicted_college_name=le_college.inverse_transform([prediction[0]])[0],
                               recommended_colleges=recommended_colleges)

    return render_template('form.html')

if __name__ == '__main__':
    app.run(debug=True)
